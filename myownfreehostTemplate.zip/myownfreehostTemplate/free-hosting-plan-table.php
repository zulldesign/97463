<table style="width: 800px;" text-align:="" width:="" border="1"
 bordercolor="#e7e7e7" cellpadding="5" cellspacing="0">
  <big> </big><tbody>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(102, 102, 102);"><big><br>
      </big></td>
      <big> </big><td style="text-align: center;"><big><span
 style="color: rgb(0, 0, 153); font-weight: bold;">Free Web Hosting Plan<br>
      </span></big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big>Monthly
Bandwidth<br>
      </big></td>
      <big> </big><td
 style="text-align: center; color: rgb(51, 51, 51);"><big>100 GB<br>
      </big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big>Web
Disk
Space<br>
      </big></td>
      <big> </big><td
 style="text-align: center; color: rgb(51, 51, 51);"><big>10 GB</big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big>Demo
Control
Panel<br>
      </big></td>
      <big> </big><td
 style="text-align: center; color: rgb(51, 51, 51);"><big><span
 style="font-weight: bold;"><a
 href="free-hosting-control-panel.php">Click
here
to view free hosting panel</a></span></big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big>Price<br>
      </big></td>
      <big> </big><td
 style="text-align: center; font-weight: bold; color: rgb(51, 51, 51);"><big>$0.00
per
month<br>
      <span style="font-weight: bold;"></span>
<a href="free-hosting-signup.php" class="premiumbutton">Signup for free hosting</a>
      </big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big>Addon
Domains<br>
      </big></td>
      <big> </big><td
 style="text-align: center; color: rgb(51, 51, 51);"><big>10<br>
      </big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big>Parked
Domains<br>
      </big></td>
      <big> </big><td
 style="text-align: center; color: rgb(51, 51, 51);"><big>10<br>
      </big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big>Sub
Domains</big></td>
      <big> </big><td
 style="vertical-align: top; text-align: center; color: rgb(51, 51, 51);"><big>10<br>
      </big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big>PHP
Sendmail<br>
      </big></td>
      <big> </big><td
 style="text-align: center; color: rgb(51, 51, 51);"><big>Limited
Sendmail() for activation
emails only<br>
      </big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big>MySQL
Databases<br>
      </big></td>
      <big> </big><td
 style="text-align: center; color: rgb(51, 51, 51);"><big>10<br>
      </big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big>FTP
Accounts<br>
      </big></td>
      <big> </big><td
 style="text-align: center; color: rgb(51, 51, 51);"><big>1<br>
      </big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big>Free
Domain<br>
      </big></td>
      <big> </big><td
 style="text-align: center; color: rgb(51, 51, 51);"><big>yourdomain.hostnamehere.com<br>
      </big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big>SiteBuilder<br>
      </big></td>
      <big> </big><td
 style="text-align: center; color: rgb(51, 51, 51);"><big><img
 style="width: 18px; height: 19px;" alt="Feature Enable"
 src="https://ifastnet.com/images/bullet1.png"></big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big>Site
Statistics<br>
      </big></td>
      <big> </big><td
 style="text-align: center; color: rgb(51, 51, 51);"><big><img
 style="width: 18px; height: 19px;" alt="Feature Enable"
 src="https://ifastnet.com/images/bullet1.png"></big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big>VistaPanel
Script
Installer<br>
      </big></td>
      <big> </big><td
 style="text-align: center; color: rgb(51, 51, 51);"><big><img
 style="width: 18px; height: 19px;" alt="Feature Enable"
 src="https://ifastnet.com/images/bullet1.png"></big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big>Custom
Error
Pages<br>
      </big></td>
      <big> </big><td
 style="text-align: center; color: rgb(51, 51, 51);"><big><img
 style="width: 18px; height: 19px;" alt="Feature Enable"
 src="https://ifastnet.com/images/bullet1.png"></big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big>Cron
Jobs<br>
      </big></td>
      <big> </big><td
 style="vertical-align: top; text-align: center; color: rgb(51, 51, 51);"><big><img
 style="width: 18px; height: 19px;" alt="Feature Enable"
 src="https://ifastnet.com/images/bullet1.png"></big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big>PHP
Flags
Manager<br>
      </big></td>
      <big> </big><td
 style="vertical-align: top; text-align: center; color: rgb(51, 51, 51);"><big><img
 style="width: 18px; height: 19px;" alt="Feature Enable"
 src="https://ifastnet.com/images/bullet1.png"></big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big>Online
Browser
File Manager<br>
      </big></td>
      <big> </big><td
 style="vertical-align: top; text-align: center; color: rgb(51, 51, 51);"><big><img
 style="width: 18px; height: 19px;" alt="Feature Enable"
 src="https://ifastnet.com/images/bullet1.png"></big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big>IP
Address
Deny</big></td>
      <big> </big><td
 style="vertical-align: top; text-align: center; color: rgb(51, 51, 51);"><big><img
 style="width: 18px; height: 19px;" alt="Feature Enable"
 src="https://ifastnet.com/images/bullet1.png"></big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big>10
MB
Max File Size<br>
      </big></td>
      <big> </big><td
 style="vertical-align: top; text-align: center; color: rgb(51, 51, 51);"><big><img
 style="width: 18px; height: 19px;" alt="Feature Enable"
 src="https://ifastnet.com/images/bullet1.png"></big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big>Custom
CNAME
Records</big></td>
      <big> </big><td
 style="vertical-align: top; text-align: center; color: rgb(51, 51, 51);"><big><img
 style="width: 18px; height: 19px;" alt="Feature Enable"
 src="https://ifastnet.com/images/bullet1.png"></big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big>Unmetered
MySQL
space<br>
      </big></td>
      <big> </big><td
 style="vertical-align: top; text-align: center; color: rgb(51, 51, 51);"><big><img
 style="width: 18px; height: 19px;" alt="Feature Enable"
 src="https://ifastnet.com/images/bullet1.png"></big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big><span
 style="font-weight: bold;"><br>
EMAIL
FEATURES</span><br>
      </big></td>
      <big> </big><td
 style="text-align: center; color: rgb(51, 51, 51);"><big><br>
      </big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big>PHP
sendmail
      </big></td>
      <big> </big><td
 style="text-align: center; color: rgb(51, 51, 51);"><big>Limited
Sendmail() for activation
emails only </big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big>WEB/POP3/IMAP4
accounts<br>
      </big></td>
      <big> </big><td
 style="text-align: center; color: rgb(51, 51, 51);"><big><img
 style="width: 31px; height: 24px;" alt="Feature Not enabled"
 src="images/x.png"></big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big>Custom
MX
records<br>
      </big></td>
      <big> </big><td
 style="text-align: center; color: rgb(51, 51, 51);"><big><img
 style="width: 18px; height: 19px;" alt="Feature Enable"
 src="https://ifastnet.com/images/bullet1.png"></big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big>Custom
SPF
records<br>
      </big></td>
      <big> </big><td
 style="vertical-align: top; color: rgb(51, 51, 51);"><big><br>
      </big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big><br>
      <span style="font-weight: bold;">SCRIPTING</span> <span
 style="font-weight: bold;">FEATURES</span><br>
      </big></td>
      <big> </big><td
 style="text-align: center; color: rgb(51, 51, 51);"><big><br>
      </big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big>PHP<br>
      </big></td>
      <big> </big><td style="text-align: center;"><big><img
 style="width: 18px; height: 19px;" alt="Feature Enable"
 src="https://ifastnet.com/images/bullet1.png"></big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big>MySQL<br>
      </big></td>
      <big> </big><td style="text-align: center;"><big><img
 style="width: 18px; height: 19px;" alt="Feature Enable"
 src="https://ifastnet.com/images/bullet1.png"></big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big>PhpMyAdmin<br>
      </big></td>
      <big> </big><td style="text-align: center;"><big><img
 style="width: 18px; height: 19px;" alt="Feature Enable"
 src="https://ifastnet.com/images/bullet1.png"></big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big><br>
      <span style="font-weight: bold;">ECOMMERCE
FEATURES</span><br>
      </big></td>
      <big> </big><td style="text-align: center;"><big><br>
      </big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big>Can
install
PHP cart scripts<br>
      </big></td>
      <big> </big><td style="text-align: center;"><big><img
 style="width: 18px; height: 19px;" alt="Feature Enable"
 src="https://ifastnet.com/images/bullet1.png"></big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big>Password
Protected
Folders<br>
      </big></td>
      <big> </big><td style="text-align: center;"><big><img
 style="width: 18px; height: 19px;" alt="Feature Enable"
 src="https://ifastnet.com/images/bullet1.png"></big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big>Bandwidth<br>
      </big></td>
      <big> </big><td style="text-align: center;"><big><img
 style="width: 18px; height: 19px;" alt="Feature Enable"
 src="https://ifastnet.com/images/bullet1.png"></big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big><br>
      <span style="font-weight: bold;">SECURITY
MECHANISM</span><br>
      </big></td>
      <big> </big><td style="text-align: center;"><big><br>
      </big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big>24/7
Monitoring<br>
      </big></td>
      <big> </big><td style="text-align: center;"><big><img
 style="width: 18px; height: 19px;" alt="Feature Enable"
 src="https://ifastnet.com/images/bullet1.png"></big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big>Firewall
Protection<br>
      </big></td>
      <big> </big><td style="text-align: center;"><big><img
 style="width: 18px; height: 19px;" alt="Feature Enable"
 src="https://ifastnet.com/images/bullet1.png"></big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big>UPS
Power
Back-up/Back-up


      <br>
      </big></td>
      <big> </big><td style="text-align: center;"><big><img
 style="width: 18px; height: 19px;" alt="Feature Enable"
 src="https://ifastnet.com/images/bullet1.png"></big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big>Generator<br>
      </big></td>
      <big> </big><td style="text-align: center;"><big><img
 style="width: 18px; height: 19px;" alt="Feature Enable"
 src="https://ifastnet.com/images/bullet1.png"></big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big>Hotlink
Protection<br>
      </big></td>
      <big> </big><td style="text-align: center;"><big><img
 style="width: 18px; height: 19px;" alt="Feature Enable"
 src="https://ifastnet.com/images/bullet1.png"></big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big><br>
      <span style="font-weight: bold;">OUR
TECHNOLOGY</span><br>
      </big></td>
      <big> </big><td style="text-align: center;"><big><br>
      </big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big>Cisco
Powered
Network<br>
      </big></td>
      <big> </big><td style="text-align: center;"><big><img
 style="width: 18px; height: 19px;" alt="Feature Enable"
 src="https://ifastnet.com/images/bullet1.png"></big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big>Linux
Clustered
Server
Network<br>
      </big></td>
      <big> </big><td style="text-align: center;"><big><img
 style="width: 18px; height: 19px;" alt="Feature Enable"
 src="https://ifastnet.com/images/bullet1.png"></big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big>Intel
Processors<br>
      </big></td>
      <big> </big><td style="text-align: center;"><big><img
 style="width: 18px; height: 19px;" alt="Feature Enable"
 src="https://ifastnet.com/images/bullet1.png"></big></td>
      <big> </big></tr>
    <big> </big><tr style="background-color: white;">
      <big> </big><td
 style="vertical-align: top; font-family: Helvetica,Arial,sans-serif; color: rgb(51, 51, 51);"><big>Apache
Web
Servers<br>
      </big></td>
      <big> </big><td style="text-align: center;"><big><img
 style="width: 18px; height: 19px;" alt="Feature Enable"
 src="https://ifastnet.com/images/bullet1.png"></big></td>
      <big> </big></tr>
    <big> </big>
  </tbody><big></big>
</table>
<br>
<center>
<a href="free-hosting-signup.php" class="premiumbutton">Signup for free hosting</a>
</center>
