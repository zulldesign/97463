<iframe  src="https://ifastnet.com//terms.html" frameborder="0" scrolling="auto" width="1000" height="2080" marginwidth="0" marginheight="0" ></iframe>
